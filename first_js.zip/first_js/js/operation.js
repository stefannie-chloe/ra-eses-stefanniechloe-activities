function sum(num1, num2) {
    const answer = num1 + num2;
    console.log("The sum is", answer);
}

function product(num1, num2) {
    const answer = num1 * num2;
    console.log("The product is", answer);
}

function difference(num1, num2) {
    const answer = num1 - num2;
    console.log("The difference is", answer);
}

function quotient(num1, num2) {
    const answer = num1 / num2;
    console.log("The quotient is", answer);
}
