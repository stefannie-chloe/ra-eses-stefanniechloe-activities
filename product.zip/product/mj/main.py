from flask import Flask, request, jsonify, render_template, redirect, url_for, session, flash
from flask_mysqldb import MySQL
import hashlib
import MySQLdb.cursors


app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# MySQL Config
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'barcena'

mysql = MySQL(app)

SALT = "barcena"

# Helper to hash password
def hash_password(password):
    return hashlib.sha256((password + SALT).encode()).hexdigest()

# ---------------- AUTH ROUTES ----------------

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = hash_password(request.form['password'])

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
        user = cur.fetchone()
        cur.close()

        if user:
            session['username'] = username
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid username or password", "error")
            return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))

    # Fetching the count of students
    cur = mysql.connection.cursor()
    cur.execute("SELECT COUNT(*) FROM student_info")
    total_students = cur.fetchone()[0]

    # Fetching the count of users (logged-in users count)
    cur.execute("SELECT COUNT(*) FROM users")
    total_users = cur.fetchone()[0]

    cur.close()

    return render_template('dashboard.html', username=session['username'], total_students=total_students, total_users=total_users)

# ---------------- STUDENT ROUTES ----------------

@app.route('/students')
def view_students():
    if 'username' not in session:
        return redirect(url_for('login'))
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM student_info")
    students = cur.fetchall()
    cur.close()
    return render_template('view_students.html', students=students)

@app.route('/students/add_form', methods=['GET', 'POST'])
def add_student_form():
    if 'username' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        cur = mysql.connection.cursor()
        cur.execute("""INSERT INTO student_info (lname, fname, mname, course, year, added_by)
                       VALUES (%s, %s, %s, %s, %s, %s)""",
                    (request.form['lname'], request.form['fname'], request.form['mname'],
                     request.form['course'], request.form['year'], session['username']))
        mysql.connection.commit()
        cur.close()
        flash("Student added successfully.", "success")
        return redirect(url_for('dashboard'))
    return render_template('add_student.html')

@app.route('/students/update_form/<int:student_id>', methods=['GET', 'POST'])
def update_student(student_id):
    if 'username' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        # Extract form data
        lname = request.form['lname']
        fname = request.form['fname']
        mname = request.form['mname']
        course = request.form['course']
        year = request.form['year']

        # Update student in the database
        cur = mysql.connection.cursor()
        cur.execute("""UPDATE student_info 
                       SET lname = %s, fname = %s, mname = %s, course = %s, year = %s
                       WHERE id = %s""", (lname, fname, mname, course, year, student_id))
        mysql.connection.commit()
        cur.close()
        flash("Student updated successfully.", "success")
        return redirect(url_for('view_students'))
    
    # Fetch the student data to pre-fill the form for editing
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM student_info WHERE id = %s", (student_id,))
    student = cur.fetchone()
    cur.close()

    if student:
        return render_template('edit_student.html', student=student)
    else:
        flash("Student not found.", "error")
        return redirect(url_for('view_students'))

@app.route('/students/delete/<int:id>', methods=['GET'])
def delete_student(id):
    if 'username' not in session:
        return redirect(url_for('login'))
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM student_info WHERE id=%s", (id,))
    mysql.connection.commit()
    cur.close()
    flash("Student deleted successfully.", "success")
    return redirect(url_for('view_students'))

@app.route('/students/search', methods=['GET', 'POST'])
def search_student():
    if 'username' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        lname = request.form['lname']
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM student_info WHERE lname LIKE %s", ('%' + lname + '%',))
        students = cur.fetchall()
        cur.close()
        return render_template('view_students.html', students=students)
    return render_template('search_student.html')

# ---------------- USER ROUTES ----------------

@app.route('/users')
def view_users():
    if 'username' not in session:
        return redirect(url_for('login'))

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT * FROM user_info")
    users = cur.fetchall()
    cur.close()

    return render_template('view_users.html', users=users)



@app.route('/user_info/<username>')
def user_info(username):
    if 'username' not in session:
        return redirect(url_for('login'))
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM user_info WHERE username=%s", (username,))
    data = cur.fetchone()
    cur.close()
    if not data:
        flash("User info not found.", "error")
        return redirect(url_for('dashboard'))
    return jsonify(data)

@app.route('/user_info/update/<username>', methods=['GET', 'POST'])
def edit_user_info(username):
    if 'username' not in session:
        return redirect(url_for('login'))

    # Fetch user data based on username
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM user_info WHERE username = %s", (username,))
    user = cur.fetchone()  # This fetches the user data based on the username
    cur.close()

    if not user:
        flash("User not found.", "error")
        return redirect(url_for('dashboard'))  # If no user is found, redirect to dashboard

    if request.method == 'POST':
        # Extract form data
        lname = request.form['lname']
        fname = request.form['fname']
        mname = request.form['mname']
        age = request.form['age']
        address = request.form['address']

        # Update user in the database
        cur = mysql.connection.cursor()
        cur.execute("""UPDATE user_info SET lname = %s, fname = %s, mname = %s, age = %s, address = %s WHERE username = %s""",
                    (lname, fname, mname, age, address, username))
        mysql.connection.commit()
        cur.close()

        flash("Profile updated successfully.", "success")
        return redirect(url_for('dashboard'))

    # When GET request, render the template with the user data
    return render_template('edit_user.html', user=user)

# ---------------- ADD USER ROUTE ----------------

@app.route('/users/add_form', methods=['GET', 'POST'])
def add_user_form():
    if request.method == 'POST':
        hashed_pw = hash_password(request.form['password'])
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users (username, password) VALUES (%s, %s)",
                    (request.form['username'], hashed_pw))
        mysql.connection.commit()
        cur.execute("""INSERT INTO user_info (username, lname, fname, mname, age, address)
                       VALUES (%s, %s, %s, %s, %s, %s)""",
                    (request.form['username'], request.form['lname'], request.form['fname'],
                     request.form['mname'], request.form['age'], request.form['address']))
        mysql.connection.commit()
        cur.close()
        flash("User added successfully.", "success")
        return redirect(url_for('login'))  # Correctly referring to 'login' route
    return render_template('add_user.html')


if __name__ == '__main__':
    app.run(debug=True)
