let x = Math.floor(Math.random() * 101);
let count = 0;
let maxTries = 5;

function checkGuess() {
    let guessInput = document.getElementById("guessInput");
    let guess = parseInt(guessInput.value);
    let message = document.getElementById("message");
    let triesLeftDisplay = document.getElementById("triesLeft");

    if (isNaN(guess)) {
        message.innerHTML = " Type a number, Girl!";
        message.style.color = "Pink";
        return;
    }

    count++;
    let triesLeft = maxTries - count;
    triesLeftDisplay.innerText = triesLeft;

    if (guess === x) {
        message.innerHTML = " You got it in ${count} tries!";
        message.style.color = "Pink";
        disableGame();
        showAgainButton(); // Show "Again?" button
    } else if (guess < x) {
        message.innerHTML = "⬆ Higher girl! ";
        message.style.color = "Pink";
        guessInput.value = ""; // Clear input
    } else {
        message.innerHTML = "⬇ lower girl! ";
        message.style.color = "Pink";
        guessInput.value = ""; // Clear input
    }

    if (triesLeft === 0) {
        message.innerHTML = " Game Over!  The right number was ${x}.";
        message.style.color = "Pink";
        disableGame();
        showRetryButton();
    }
}

function disableGame() {
    document.getElementById("guessInput").disabled = true;
    document.querySelector("button").disabled = true;
}

function showAgainButton() {
    let againButton = document.createElement("button");
    againButton.innerHTML = " Again?";
    againButton.style.display = "block";
    againButton.style.margin = "15px auto";
    againButton.onclick = resetGame;
    document.querySelector(".game-container").appendChild(againButton);
}

function showRetryButton() {
    let retryButton = document.createElement("button");
    retryButton.innerHTML = " Try Again";
    retryButton.style.display = "block";
    retryButton.style.margin = "15px auto";
    retryButton.onclick = resetGame;
    document.querySelector(".game-container").appendChild(retryButton);
}

function resetGame() {
    x = Math.floor(Math.random() * 101);
    count = 0;
    let guessInput = document.getElementById("guessInput");
    
    guessInput.value = "";
    guessInput.disabled = false;
    document.querySelector("button").disabled = false;
    document.getElementById("message").innerHTML = "";
    document.getElementById("triesLeft").innerText = maxTries;

    // Remove all extra buttons
    let buttons = document.querySelectorAll(".game-container button");
    if (buttons.length > 1) {
        buttons[1].remove(); // Remove "Again?" or "Try Again" button
    }
}